import java.util.Scanner;

public class Main {
public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    int idxMhs = 0;
    int idxmtkl = 0;
    int idxPenilaian = 0;
    int index = 5;
        
        Mahasiswa [] mahasiswa = new Mahasiswa[3];
        mahasiswa[0] = new Mahasiswa("22001", "Ali Rahman", "Informatika");
        mahasiswa[1] = new Mahasiswa("22002", "Budi Santoso", "Informatika");
        mahasiswa[2] = new Mahasiswa("22003", "Citra Dewi", "Sistem Informasi Bisnis");

        MataKuliah [] mataKuliah = new MataKuliah[3];
        mataKuliah[0] = new MataKuliah("MK001", "Strukur Data", 3);
        mataKuliah[1] = new MataKuliah("MK002", "Basis Data", 3);
        mataKuliah[2] = new MataKuliah("MK001", "Desain Web", 3);

        Penilaian [] penilaian = new Penilaian[5];
        penilaian[0] = new Penilaian(mahasiswa[0], mataKuliah[0], 80, 85, 90);
        penilaian[1] = new Penilaian(mahasiswa[0], mataKuliah[1], 60, 75, 70);
        penilaian[2] = new Penilaian(mahasiswa[1], mataKuliah[0], 75, 70, 80);
        penilaian[3] = new Penilaian(mahasiswa[2], mataKuliah[1], 85, 90, 95);
        penilaian[4] = new Penilaian(mahasiswa[2], mataKuliah[2], 80, 90, 65);

        while (true) {
            System.out.println("\n=== MENU SISTEM AKADEMIK ===");
            System.out.println("1. Tampilkan Daftar Mahasiswa");
            System.out.println("2. Tampilkan Daftar Mata Kuliah");
            System.out.println("3. Tampilkan Data Penilaian");
            System.out.println("4. Urutkan Mahasiswa Berdasarkan Nilai Akhir");
            System.out.println("5. Cari Mahasiswa Berdasarkan NIM");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu: ");
            int menu = sc.nextInt();
            
            sc.nextLine();

            switch (menu) {
                case 1:
                    System.out.println("\nDaftar Mahasiswa: ");
                    Mahasiswa mhs = new Mahasiswa();
                    mhs.tampilMahasiswa(mahasiswa);
                    break;
                case 2:
                    System.out.println("\nDaftar Mata Kuliah: ");
                    MataKuliah mK = new MataKuliah();
                    mK.tampilMatakuliah(mataKuliah);
                    break;
                case 3:
                    System.out.println("\nData Penilaian: ");
                    Penilaian nilai = new Penilaian();
                    nilai.tampilDataPenilaian(penilaian);
                    break;
                case 4:
                    System.out.println("\nData Penilaian: ");
                    Penilaian dataASC = new Penilaian();
                    dataASC.sortingDSC(penilaian, index);
                    break;
                case 5:
                    System.out.print("Masukkan NIM yang ingin dicari: ");
                    String cariNIM = sc.nextLine();
                    Penilaian searchNIM = new Penilaian();
                    searchNIM.sequentialSearching(cariNIM, mahasiswa);
                    break;
                case 0: 
                    System.out.println("Berhasil keluar dari program.");
                    sc.close();
                    return;
                
                default:
                    System.out.println("Pilihan tidak valid, coba lagi.");
            }
        }
    }
}
