public class Penilaian {
    Mahasiswa mahasiswa = new Mahasiswa();
    MataKuliah mataKuliah = new MataKuliah();
    double nilaiTugas;
    double nilaiUTS;
    double nilaiUAS;
    double nilaiAkhir;

    Penilaian[] penilaian = new Penilaian[5];
    // int index = 0;
    
    Penilaian(Mahasiswa mahasiswa, MataKuliah mataKuliah, double tugas, double uts, double uas){
        this.mahasiswa = mahasiswa;
        this.mataKuliah = mataKuliah;
        nilaiTugas = tugas;
        nilaiUTS = uts;
        nilaiUAS = uas;
        hitungNilaiAkhir();
    }
    
    void hitungNilaiAkhir(){
        nilaiAkhir = (0.3*nilaiTugas) + (0.3*nilaiUTS) + (0.4*nilaiUAS);
    }
    
    Penilaian(){
        
    }

    void tampilDataPenilaian(Penilaian[] penilaian){
        for (int i = 0; i < penilaian.length; i++) {
            System.out.println(penilaian[i].mahasiswa.nama + " | " + 
            penilaian[i].mataKuliah.namaMK + " | Nilai Akhir: " + penilaian[i].nilaiAkhir);
        }
    }

    static void sortingDSC(Penilaian[] penilaian, int index){
        for (int i = 0; i < index - 1; i++) {
            int maxIdx = i;
            for (int j = i + 1; j < index; j++) {
                if (penilaian[j].nilaiAkhir > penilaian[maxIdx].nilaiAkhir) {
                    maxIdx = j;
                }
            }
            Penilaian temp = penilaian[maxIdx];
            penilaian[maxIdx] = penilaian[i];
            penilaian[i] = temp;
        }
        for(int i=0; i<index;i++){
            System.out.println(penilaian[i].mahasiswa.nama + " | " + 
            penilaian[i].mataKuliah.namaMK + " | " + penilaian[i].nilaiAkhir);
        }           
    }

    void sequentialSearching(String cariNIM, Mahasiswa[] mahasiswa){
        boolean found = false;    
        for(Mahasiswa mhs : mahasiswa) {
            if(mhs.nim.equals(cariNIM)){
                System.out.print("Mahasiswa ditemukan: NIM: " + 
                mhs.nim + " | Nama: "+ mhs.nama + " | Prodi: " + mhs.prodi);
                found = true;
                break;
            }
        }
        if(!found){
            System.out.println("Mahasiswa dengan NIM tersebut tidak ditemukan.");
        }
        
        System.out.println();
    }
}