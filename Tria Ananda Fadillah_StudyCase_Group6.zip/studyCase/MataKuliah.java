public class MataKuliah {

    String kodeMK;
    String namaMK;
    int sks;

    MataKuliah(String kdMK, String nmMK, int sks) {
        this.kodeMK = kdMK;
        this.namaMK = nmMK;
        this.sks = sks;
    }

    MataKuliah(){
        
    }

    void tampilMatakuliah(MataKuliah[] mataKuliah) {
        for (int i = 0; i < mataKuliah.length; i++) {
            System.out.println("Kode MK: " + mataKuliah[i].kodeMK + " | " + 
            "Nama: " + mataKuliah[i].namaMK + " | SKS: " + mataKuliah[i].sks);
        }
    }
}