public class Mahasiswa{
    String nim;
    String nama;
    String prodi;

    Mahasiswa ( String nim, String nama, String prodi){
        this.nim = nim;
        this.nama = nama;
        this.prodi = prodi;
    }
    
    Mahasiswa(){
         
    }

    void tampilMahasiswa(Mahasiswa[] mahasiswa){
        for (int i = 0; i < mahasiswa.length; i++) {
            System.out.println("NIM: " + mahasiswa[i].nim + " | " + 
            "Nama: " + mahasiswa[i].nama + " | Prodi: " + mahasiswa[i].prodi);
        }
    }
}